export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyAkGn-ieErcsEGx4hRXGihRWRouhOP7Ol4",
        authDomain: "sports-stats-now-a5465.firebaseapp.com",
        projectId: "sports-stats-now-a5465",
        storageBucket: "sports-stats-now-a5465.firebasestorage.app",
        messagingSenderId: "981498643014",
        appId: "1:981498643014:web:a7d7afee03e52719bb8047"
    }
  };
  